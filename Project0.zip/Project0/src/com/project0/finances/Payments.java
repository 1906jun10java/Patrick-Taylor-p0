package com.project0.finances;

public class Payments {

}
