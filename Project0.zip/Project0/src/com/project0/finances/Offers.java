package com.project0.finances;

public class Offers {

}
