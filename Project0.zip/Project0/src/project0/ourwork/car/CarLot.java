package project0.ourwork.car;

public class CarLot {

}
