package project0.ourwork.inventory;


import project0.ourwork.CarLot;


public class Car extends CarLot{	
	/*
	 * For the Car class, we can implement the methods for:
	 * view the cars on the lot
	 * 
	 * add or remove cars from the lot 
	 * 
	 * sort cars
	 */
	
		public boolean addCarsToLot(Car e) {//method for adding cars to the lot
			
			return true;  
			
		}
	
	}
